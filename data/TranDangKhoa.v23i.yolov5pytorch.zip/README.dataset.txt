# TranDangKhoa > 2025-07-15 8:56pm
https://universe.roboflow.com/fb-3bmbn/trandangkhoa

Provided by a Roboflow user
License: CC BY 4.0

